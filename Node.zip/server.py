import time

stop = True

while stop:
    print('...')
    time.sleep(1)
